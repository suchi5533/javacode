/**
 * 
 */
/**
 * @author admin
 *
 */
module javafullstackprepration {
}